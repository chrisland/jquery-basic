

// hier der javascript / jquery code


alert('ich bin das jquery demo');